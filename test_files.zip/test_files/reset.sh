rm hash_data
rm file_data
rm directory_table
cp hash_data.before hash_data
cp file_data.before file_data
cp directory_table.before directory_table
